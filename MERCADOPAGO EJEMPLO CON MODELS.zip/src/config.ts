import dotenv from 'dotenv'

dotenv.config()
export const ACCES_TOKEN = process.env.ACCES_TOKEN
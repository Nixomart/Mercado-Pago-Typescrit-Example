/* import app from './app'
import {sequelize} from './database/database'

async function main() {
    try {
        await sequelize.sync({force: false})
        app.listen(3000)
        console.log("in port: 3000")
    } catch (error) {
        console.log('error', error)
    }
}
main() */


